#!/bin/bash -l
./twistcli coderepo scan --address https://$TL_CONSOLE --details -u $TL_USER -p $TL_PASS ./app