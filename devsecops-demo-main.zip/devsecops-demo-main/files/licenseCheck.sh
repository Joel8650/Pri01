#!/bin/bash -l

./twistcli coderepo scan --address https://$TL_CONSOLE -u $TL_USER -p $TL_PASS ./license  

