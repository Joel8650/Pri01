# devsecops-demo
DevSecOps Demo based on Jenkins CI/CD Pipeline to show Prisma Cloud Integration
